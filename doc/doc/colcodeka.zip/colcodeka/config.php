<?php

	// Variables para la conexi�n
	
	global $Usuario;  /*root*/
	global $Password;
	global $Servidor; /*localhost*/
	global $BaseDeDatos;
	
	$Usuario="tumodavi_codeka";         /* nombre de usuario de la base de datos */
	$Password="Colcodeka1";      /* Contrase�a de la base de datos */
	$Servidor="localhost";   /* Servidor , generalmente localhost*/
	$BaseDeDatos="tumodavi_colcodeka"; /* Nombre de la base de datos */

?>
