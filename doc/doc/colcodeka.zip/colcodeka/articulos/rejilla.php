<?php
	include ("../conectar.php");
	
	$codarticulo	= $_POST["codarticulo"];
	$descripcion	= $_POST["descripcion"];
	$codfamilia		= $_POST["cboFamilias"];
	$referencia		= $_POST["referencia"];
	$codproveedor	= $_POST["cboProveedores"];
	$codubicacion	= $_POST["cboUbicacion"];
	
	$cadena_busqueda= $_POST["cadena_busqueda"];
	
	$where="1=1";
	if ($codarticulo <> "")  { $where.=" AND codarticulo='$codarticulo'"; }
	if ($descripcion <> "")  { $where.=" AND descripcion like '%".$descripcion."%'"; }
	if ($codfamilia > "0")   { $where.=" AND codfamilia='$codfamilia'"; }
	if ($codproveedor > "0") { $where.=" AND (codproveedor1='$codproveedor' OR codproveedor2='$codproveedor')"; }
	if ($codubicacion > "0") { $where.=" AND codubicacion='$codubicacion'"; }
	if ($referencia <> "")   { $where.=" AND referencia like '%".$referencia."%'"; }
	
	$where.=" ORDER BY codarticulo ASC";
	$query_busqueda="SELECT count(*) as filas FROM articulos WHERE borrado=0 AND ".$where;
	$rs_busqueda=mysql_query($query_busqueda);
	$filas=mysql_result($rs_busqueda,0,"filas");

?>
<html>
	<head>
		<title>Articulos</title>
		<link href="../estilos/estilos.css" type="text/css" rel="stylesheet">
		<script language="javascript">
		
		function ver_articulo(codarticulo) {
			parent.location.href="ver_articulo.php?codarticulo=" + codarticulo + "&cadena_busqueda=<? echo $cadena_busqueda?>";
		}
		
		function modificar_articulo(codarticulo) {
			parent.location.href="modificar_articulo.php?codarticulo=" + codarticulo + "&cadena_busqueda=<? echo $cadena_busqueda?>";
		}
		
		function cambiar_imagen(codarticulo) {
			parent.location.href="cambiar_imagen.php?codarticulo=" + codarticulo + "&cadena_busqueda=<? echo $cadena_busqueda?>";
		}
		
		function eliminar_articulo(codarticulo) {
			parent.location.href="eliminar_articulo.php?codarticulo=" + codarticulo + "&cadena_busqueda=<? echo $cadena_busqueda?>";
		}

		function inicio() {
			var numfilas	= document.getElementById("numfilas").value;
			var indi		= parent.document.getElementById("iniciopagina").value;
			var contador	= 1;
			var indice		= 0;
			
			if (indi>numfilas) { 
				indi=1; 
			}
			parent.document.form_busqueda.filas.value=numfilas;
			parent.document.form_busqueda.paginas.innerHTML="";		
			while (contador<=numfilas) {
				texto=contador + "-" + parseInt(contador+9);
				if (indi==contador) {
					parent.document.form_busqueda.paginas.options[indice]=new Option (texto,contador);
					parent.document.form_busqueda.paginas.options[indice].selected=true;
				} else {
					parent.document.form_busqueda.paginas.options[indice]=new Option (texto,contador);
				}
				indice++;
				contador=contador+10;
			}
		}
		</script>
	</head>

	<body onload=inicio()>	
		<div id="pagina">
			<div id="zonaContenidoPP">
			
            <div align="center">
            
			<table class="fuente8" width="100%" cellspacing=0 cellpadding=3 border=0 ID="Table1">
			<input type="hidden" name="numfilas" id="numfilas" value="<? echo $filas?>">
            
				<? 
					$iniciopagina = $_POST["iniciopagina"];
					if (empty($iniciopagina)) { 
						$iniciopagina = $_GET["iniciopagina"]; 
					} 
					else { 
						$iniciopagina = $iniciopagina-1;
					}
					if (empty($iniciopagina)) { $iniciopagina=0; }
					if ($iniciopagina>$filas) { $iniciopagina=0; }
					if ($filas > 0) { 
				?>
					<? 
						$sel_resultado = "SELECT * FROM articulos WHERE borrado=0 AND ".$where;
						$sel_resultado = $sel_resultado."  limit ".$iniciopagina.",10";
						$res_resultado = mysql_query($sel_resultado);
						$contador      = 0;
						
						   while ($contador < mysql_num_rows($res_resultado)) 
						   { 
						   		if ($i % 2) { 
									$fondolinea="itemParTabla"; 
								} 
								else { 
									$fondolinea="itemImparTabla";	
								}
								?>
								<tr class="<?php echo $fondolinea?>">
								<td class="aCentro" width="4%"><? echo $contador+1;?></td>
								<td width="5%">
                                	<div align="center">
										<? echo mysql_result($res_resultado,$contador,"codarticulo")?>
                                    </div>
                                </td>
								<td width="19%">
                                	<div align="left">
										<? echo mysql_result($res_resultado,$contador,"referencia")?>
                                    </div>
                                </td>
								<td width="30%">
                                	<div align="left">
										<? echo mysql_result($res_resultado,$contador,"descripcion")?>
                                    </div>
                                </td>
								<td width="11%">
                                	<div align="left"><!--nombre para el producto-->
									<? 
										$codfamilia     = mysql_result($res_resultado,$contador,"codfamilia");
										$query_familia  = "SELECT nombre FROM familias WHERE codfamilia='$codfamilia'";
										$rs_familia     = mysql_query($query_familia);
										$nombre_familia = mysql_result($rs_familia,0,"nombre");
										echo $nombre_familia;			
									?>
									</div>
                            	</td>
								<td class="aCentro" width="11%">
                                    <div align="center"><!--precio para el producto-->
                                    <? 
										echo mysql_result($res_resultado,$contador,"precio_tienda")
									?>
                                    </div>
                                </td>
								<td class="aCentro" width="5%"><!--stock para el producto-->
									<? 
										echo mysql_result($res_resultado,$contador,"stock")
									?>
                                </td>
								<td width="5%"><!--modificar para el producto-->
                                	<div align="center">
                                    	<a href="#">
                                    	<img src="../img/modificar.png" width="16" height="16" border="0" onClick="modificar_articulo(<?php echo mysql_result($res_resultado,$contador,"codarticulo")?>)" title="Modificar">
                                    	</a>
                                	</div>
                            	</td>
                                <td width="5%"><!--detalle para el producto-->
                                    <div align="center">
                                        <a href="#">
                                            <img src="../img/ver.png" width="16" height="16" border="0" onClick="ver_articulo(<?php echo mysql_result($res_resultado,$contador,"codarticulo")?>)" title="Visualizar">
                                        </a>
                                     </div>
                                 </td>
                                <td width="5%"><!--eliminar para el producto-->
                                    <div align="center">
                                        <a href="#">
                                            <img src="../img/eliminar.png" width="16" height="16" border="0" onClick="eliminar_articulo(<?php echo mysql_result($res_resultado,$contador,"codarticulo")?>)" title="Eliminar">
                                        </a>
                                     </div>
                                 </td>
                                <td width="5%"><!--Cambiar imagen para el producto-->
                                    <div align="center">
                                        <a href="#">
                                            <img src="../img/img_change.gif" width="16" height="16" border="0" onClick="cambiar_imagen(<?php echo mysql_result($res_resultado,$contador,"codarticulo")?>)" title="Modificar imagen">
                                        </a>
                                    </div>
                                </td>
							</tr>
						<? 
							//este el contador de WHILE
							$contador++;
							}
						?>			
					</table>
					<? } else { ?>
					<table class="fuente8" width="87%" cellspacing=0 cellpadding=3 border=0>
						<tr>
							<td width="100%" class="mensaje"><?php echo "No hay ning&uacute;n art&iacute;culo que cumpla con los criterios de b&uacute;squeda";?></td>
					    </tr>
					</table>					
					<? } ?>					
				</div><!-- end  align="center"-->
                
			</div><!-- end  id="zonaContenidoPP"-->
            
		  </div>			
		</div>
	</body>
</html>
