<?php 
	include_once('CustomSmarty.php');
	if(isset($_GET["cerrar"])){
		echo "Entra en el index cerrar session";
		
		echo '<script type="text/javascript">';
		echo 'window.parent.document.getElementById("principal").style.display=\'none\'; ';
		echo '</script>';
	}
		$smarty = new CustomSmarty();
		$smarty->display('VstIndex.tpl');
	
?>