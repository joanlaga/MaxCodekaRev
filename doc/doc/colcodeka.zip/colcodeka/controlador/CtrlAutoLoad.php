<?php
    function autoload_controlador($class_name) {
		
        $rutasClases = array('../','../modelo/dao/','../modelo/vo/','../modelo/');
		
		$extList='.php';
		
		$exts = explode(',',$extList);
		
		foreach($exts as $ext) {
			foreach($rutasClases as $dir) {
				$file = $dir.$class_name.$ext;
				if(file_exists($file)) {
					include($file);
				}
			}
		}
    }
    spl_autoload_register('autoload_controlador');
?>