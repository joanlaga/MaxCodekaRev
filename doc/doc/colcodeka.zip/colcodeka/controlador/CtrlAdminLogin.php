<?php
	
	require_once("CtrlAutoLoad.php");
	
	$ctrlAdminVentas = new CtrlAdminLogin();
	
	if(isset($_POST) && sizeof($_POST) != 0){
		$ctrlAdminVentas->initPost($_POST);
	}
	else if(isset($_GET) && sizeof($_GET) != 0){
		$ctrlAdminVentas->iniGet($_GET);
	}
	else{
		$ctrlAdminVentas->paginaAdmin();
	}
	
	class CtrlAdminLogin{
		
		const VISTA_COLCODEKA = 'VstColcodeka.tpl';
		const VISTA_ERROR     = 'VstDefault.tpl';
		
		public  $smarty;
		private $login; 
		private $mdlLogin;
		private $mdlCaja;
		
		public function __construct(){
			$this->smarty   = new CustomSmarty();
			$this->mdlLogin = new MdlLogin();
			$this->mdlCaja  = new MdlCaja();
		}
		
		public function paginaAdmin(){
			session_start();
			session_unset();
			session_destroy();
			header ("location:../index.php?cerrar=true"); 
		}
		
		public function iniGet($get){}
		
		public function initPost($post){
			if ($post['Submit']=='Aceptar'){
				$this->ingresar($post);
			}
		}
		
		private function ingresar($post){
			
			if($this->mdlLogin->iniciaSession($post['usuario'],$post['clave'])){
				session_start(); 
				$_SESSION['usuario_rol'] = $this->mdlLogin->datos["idUserRol"];
				$_SESSION['usuario_id']  = $this->mdlLogin->datos["idUser"];
				$_SESSION['usuario_nom'] = strtoupper($this->mdlLogin->datos["primerNombre"]);
				
				//$this->verificarCierreCaja($this->mdlLogin->datos["idUser"]);
				
				$this->smarty->assign('usuario_rol',$_SESSION['usuario_rol']);
				$this->smarty->assign('usuario_id',$_SESSION['usuario_id']);
				$this->smarty->assign('usuario_nom',strtoupper($_SESSION['usuario_nom']));
				$this->smarty->display(CtrlAdminLogin::VISTA_COLCODEKA);
				
			}
			else {
				$this->smarty->display(CtrlAdminLogin::VISTA_ERROR); 
			}
			
		}
		//en remojo por que no es necesario hacer cerrar session para cerrar caja puedo dejar la caja abierta por varios dias.????
		private function verificarCierreCaja($idUser){
			if($this->mdlCaja->estaAbierta($idUser)){
				/*echo "<pre>";
					print_r($this->mdlCaja->datos);
				echo "</pre>";*/
				$this->mdlCaja->cerrar($this->mdlCaja->datos["billetesApertura"],$this->mdlCaja->datos["monedasApertura"],$this->mdlCaja->datos["idCaja"]);
			}
		}
		
	}//end class
?>