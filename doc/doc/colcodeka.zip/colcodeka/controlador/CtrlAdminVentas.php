<?
	require_once("CtrlAutoLoad.php");
	require_once("../funciones/fechas.php");
	
	$ctrlAdminVentas = new CtrlAdminVentas();
	
	if(isset($_POST) && sizeof($_POST) != 0){
		$ctrlAdminVentas->initPost($_POST);
	}
	else if(isset($_GET) && sizeof($_GET) != 0){
		$ctrlAdminVentas->iniGet($_GET);
	}
	else{
		$ctrlAdminVentas->paginaAdmin();
	}
	
	class CtrlAdminVentas{
		
		const VISTA_ADMINISTRAR = 'VstAdminVentas.tpl';
		const VISTA_ARTICULOS   = 'VstVentasVerArticulos.tpl';
		const VISTA_DETALLE     = 'VstVentasGrillaLineas.tpl';
		const VISTA_PAGAR       = 'VstVentasPagarFactura.tpl';
		const VISTA_ERROR       = 'VstDefault.tpl';
		const VISTA_IMPRESION   = 'VstVentasImprimirFactura.tpl';
		const VISTA_GRILLA_ARTICULOS  = 'VstVentasGrillaArticulos.tpl';
		
		public  $smarty;
		private $codUsuario;
		public  $mdlParametrizacion;
		private $mdlFacturacion;
		private $mdlCategoriaArticulo;
		private $mdlArticulos;
		private $mdlCaja;
		private $mdlCliente;
		private $productosFactura;
		
		private $voFabrica;
		
		public function __construct(){
			session_start(); 
			$this->codUsuario 		      = $_SESSION['usuario_id']; 
			$this->smarty          		  = new CustomSmarty();	
			$this->mdlParametrizacion 	  = new MdlParametrizacion();
			$this->mdlFacturacion     	  = new MdlFacturacion();
			$this->mdlCategoriaArticulo   = new MdlCategoriaArticulo();
			$this->mdlArticulos 		  = new MdlArticulos();
			$this->mdlCliente             = new MdlCliente();
			$this->mdlCaja				  = new MdlCaja();
		}
		
		public function paginaAdmin(){
			$this->voFabrica = VOFabrica::crear(VOFabrica::CAJA);
			$this->voFabrica->idUser = $this->codUsuario;
			
			if($this->mdlCaja->estaAbierta($this->voFabrica)){
				
				$this->voFabrica = VOFabrica::crear(VOFabrica::FACTURA_TEMP);
				$this->voFabrica->idCaja = $this->mdlCaja->voFabrica->idCaja;
				$codfacturatmp   = $this->mdlFacturacion->generarCodigoTemporal($this->voFabrica);
				
				$hoy = date("d/m/Y");
				$this->smarty->assign("hoy",$hoy );
				$this->smarty->assign("ivaimp",$this->mdlParametrizacion->ivaimp);
				$this->smarty->assign("simbolomoneda",$this->mdlParametrizacion->simbolomoneda);
				$this->smarty->assign("codfacturatmp",$codfacturatmp);
				$this->smarty->assign("precioSinIva",0);
				$this->smarty->assign("preciototal",0);
				$this->smarty->display(CtrlAdminVentas::VISTA_ADMINISTRAR);
			}
			else {
				?>
					<script>
                        alert("La Caja no se encuentra disponible o NO se ha dado Apertura");
                    </script>
                
                <? 
			}			
		}
		
		public function iniGet($get){
			if($get["accion"] == "imprimirFactura"){
				$this->imprimirFactura();
			}
		}
		
		public function initPost($post){
			if($post["accion"] == "abrirCaja"){
				$this->voFabrica = VOFabrica::crear(VOFabrica::CAJA);
				$this->voFabrica->valorApertura = $post["totalConsignacion"];
				$this->voFabrica->idUser 		= $this->codUsuario;
				$this->mdlCaja->abrir($this->voFabrica);
				$this->paginaAdmin();
			}
			else if($post["accion"] == "verArticulos"){
				$this->mdlCategoriaArticulo->cargarArticulos();
				$this->smarty->assign('opc_articulos',$this->mdlCategoriaArticulo->toArray());
				$this->smarty->display(CtrlAdminVentas::VISTA_ARTICULOS);
			}
			else if($post["accion"] == "verGrillaArticulos"){
				if($post["cmbfamilia"]<>0)
				{
					$this->llenarGrillaProductos('familia');
				}
				else if($post["referencia"]<>""){
					$this->llenarGrillaProductos('referencia');
				}
				else if($post["descripcion"]<>""){
					$this->llenarGrillaProductos('descripcion');
				}
				else{
					$this->llenarGrillaProductos('*');
				}
			}
			else if($post["accion"] == "agregarProducto"){
				$this->agregarProductoTablaFacturaTmp($post);
			}
			else if($post["accion"] == "guardarFactura"){
				$this->guardarFacturarAPagar($post);
			}
			else if($post["accion"] == "efectuarPago"){
				$this->efectuarPago($post);
			}
		}
		
		public function llenarGrillaProductos($busqueda){
			$this->mdlCategoriaArticulo->buscar($busqueda);
			$this->smarty->assign('result_busqueda',$this->mdlCategoriaArticulo->toArray());
			$this->smarty->display(CtrlAdminVentas::VISTA_GRILLA_ARTICULOS);
		}
		
		private function agregarProductoTablaFacturaTmp($post){
			
			$codfacturatmp = $post["codfacturatmp"];
			
			if (!isset($codfacturatmp)) { 
				$codfacturatmp	= $_GET["codfacturatmp"]; 
			}	
			$codbarras	= $post["codbarras"];
			$this->voFabrica = VOFabrica::crear(VOFabrica::ARTICULO);
			$this->voFabrica->codigobarras = $codbarras;
			//cuando en el modelo se da buscar el carga en su VO los datos encontrados
			$this->mdlArticulos->buscar('codigoBarras',$this->voFabrica);
			
			$codfamilia   = $this->mdlArticulos->voFabrica->codfamilia;  //$resultBusqueda["codfamilia"];
			$codarticulo  = $this->mdlArticulos->voFabrica->codarticulo; //$resultBusqueda["codarticulo"];
			
			//se crea un nuevo medio de transporte de datos
			$this->voFabrica = VOFabrica::crear(VOFabrica::FACTURA_LINEA);
			$this->voFabrica->codfactura = $codfacturatmp;
			$this->voFabrica->codfamilia = $codfamilia;
			$this->voFabrica->codigo     = $codarticulo;
			$this->voFabrica->cantidad 	 = $post["cantidad"];;
			$this->voFabrica->precio	 = $post["precio"];;
			$this->voFabrica->importe 	 = $post["importe"];;
			$this->voFabrica->dcto 		 = $post["descuento"];
			
			$this->mdlFacturacion->generarCodigoLineaTemporal($this->voFabrica);
			
			$resultBusqueda = $this->mdlFacturacion->buscarPorFacturasLineasTmp($this->voFabrica);
			
			$arrayLength    = count($resultBusqueda);
			
			if ($arrayLength != 0 ) {
				
				$this->smarty->assign('baseImpuestos',$this->mdlFacturacion->baseTotalImpuestosFact); 
				$this->smarty->assign('precioSinIva',$this->mdlFacturacion->precioTotalFactSinIva);
				$this->smarty->assign('precioTotal',$this->mdlFacturacion->precioTotalFact);
				
				$this->smarty->assign('lineas',$resultBusqueda);
				$this->smarty->display(CtrlAdminVentas::VISTA_DETALLE);
			}
			else {
				$this->smarty->display(CtrlAdminVentas::VISTA_ERROR);
			}
		}
		
		private function guardarFacturarAPagar($post){
			
			$this->voFabrica = VOFabrica::crear(VOFabrica::FACTURA);
			
			$codcliente     = $pos["codcliente"];
			$fechaFactura   = $post["fecha"];
			$codfacturatmp  = $post["codfacturatmp"];
			$codcliente		= $post["codcliente"];
			
			
			$this->voFabrica->codcliente = $codcliente;
			$codfactura	   = $this->mdlFacturacion->generarCodFactura($this->voFabrica);
			$this->voFabrica->codfactura   = $codfactura;
			
			$this->mdlFacturacion->copiarProdFactLineaTmpAFactReal($codfacturatmp,$codfactura);
			$this->voFabrica->totalfactura = $this->mdlFacturacion->precioTotalFact;
			$this->voFabrica->precioTotalSinIva = $this->mdlFacturacion->precioTotalFactSinIva;
			$this->voFabrica->totalImpuestos  = $this->mdlFacturacion->baseTotalImpuestosFact;
			$this->mdlFacturacion->actualizarPrecioFactura($this->voFabrica);
			
			$formasPago    = $this->mdlFacturacion->seleccionarFormasDePago();
			$this->obtenerDatosCliente($codcliente);
			
			$this->smarty->assign('baseImpuestos',$this->mdlFacturacion->baseTotalImpuestosFact); 
			$this->smarty->assign('precioSinIva',$this->mdlFacturacion->precioTotalFactSinIva);
			$this->smarty->assign('precioTotal',$this->mdlFacturacion->precioTotalFact);
			$this->smarty->assign('factCobrada',false);
			$this->smarty->assign('fechaFactura',$fechaFactura);
			$this->smarty->assign('codFactura',$codfactura);
			$this->smarty->assign('opc_formasPago',$formasPago);
			$this->smarty->assign('msgMinimo',$this->mdlFacturacion->msgMinimo);
			
			$this->productosFactura  = $this->mdlFacturacion->seleccionarProductosFactura($codfactura);
			$this->smarty->assign('lineas',$this->productosFactura);
			$this->smarty->display(CtrlAdminVentas::VISTA_PAGAR);
			
		}//guardar factura
		
		private function obtenerDatosCliente($codcliente){
			$this->voFabrica = VOFabrica::crear(VOFabrica::CLIENTE);
			$this->voFabrica->codcliente = $codcliente;
			
			$this->mdlCliente->buscarPorCodigoCliente($this->voFabrica);
			
			$this->smarty->assign('clienteCodigo',$this->mdlCliente->voFabrica->codcliente);
			$this->smarty->assign('clienteNombre',$this->mdlCliente->voFabrica->nombre);
			$this->smarty->assign('clienteNif',	$this->mdlCliente->voFabrica->nif);
			$this->smarty->assign('clienteDireccion', $this->mdlCliente->voFabrica->direccion);
			$this->smarty->assign('clienteCodProvincia', $this->mdlCliente->voFabrica->codprovincia);
			$this->smarty->assign('clienteLocalidad', $this->mdlCliente->voFabrica->localidad);
			$this->smarty->assign('clienteCodFormapago', $this->mdlCliente->voFabrica->codformapago);
			$this->smarty->assign('clienteCodEntidad', $this->mdlCliente->voFabrica->codentidad);
			$this->smarty->assign('clienteTelefono',$this->mdlCliente->voFabrica->telefono);
			$this->smarty->assign('clienteEmail',$this->mdlCliente->voFabrica->email);	
		}
		
		private function eliminarProductosGrillaFacturaLineaTmp(){
			/*$codfactura=$_GET["codfacturatmp"];
			$numlinea=$_GET["numlinea"];
									 
			$consulta = "DELETE FROM factulineatmp WHERE codfactura ='".$codfactura."' AND numlinea='".$numlinea."'";
			$rs_consulta = mysql_query($consulta);
			echo "<script>parent.location.href='frame_lineas.php?codfacturatmp=".$codfactura."';</script>";
			?>
			<script>parent.document.getElementById("codbarras").focus();</script>*/
		}
		
		private function efectuarPago($post){
			$codfactura	= $post["cod_factura"];
			$codcliente	= $post["cod_cliente"];
			$importe	= $post["precioTotal"];
			
			//no se ha implementado la forma de pago vale
			//$importevale=$_POST["importevale"];
			//$importe=$importe-$importevale;
			//$numdocumento=$_POST["numdocumento"];
			$numdocumento = 0; //por el momento
			
			// OJO REVISAR EL FORMATO DE LA FECHA echo $fechacobro; 
			$codformapago	= $post["formapago"];
			
			$this->voFabrica = VOFabrica::crear(VOFabrica::COBRO);
			$this->voFabrica->codfactura = $codfactura;
			
			if ($this->mdlFacturacion->comprobarCobroFactura($this->voFabrica)) {
					$this->voFabrica->codcliente = $codcliente;
					$this->voFabrica->importe 	 = $importe;
					$this->voFabrica->importe 	 = $importe;
					$this->voFabrica->codformapago = $codformapago;
					$this->voFabrica->numdocumento = $numdocumento;
					$this->mdlFacturacion->nuevoCobro($this->voFabrica);
					
					$this->mdlFacturacion->nuevoLibroDiario($codfactura,$codcliente,$formapago,$numdocumento,$importe);
					$this->voFactura->codfactura = $codfactura; 
					$this->mdlFacturacion->actualizarEstadoFactura($this->voFactura);
					?>
						<script>
							alert("El cobro se ha efectuado correctamente");
						</script>
					
					<? 
			}else{
				?>
					<script>
						alert("Esta factura ya se cobro con anterioridad");
					</script>
				<?
			}
			
			// Inicio Recargar pagina 
				$formasPago = $this->mdlFacturacion->seleccionarFormasDePago();
				$this->smarty->assign('factCobrada',true);
				$this->smarty->assign('adevolver',$post["adevolver"]);
				$this->smarty->assign('pagado',$post["pagado"]);
				$this->smarty->assign('fechaFactura',$post["fecha_factura"]);
				$this->smarty->assign('codFactura',$codfactura);
				$this->smarty->assign('baseImpuestos',$post["baseImpuestos"]); 
				$this->smarty->assign('precioSinIva',$post["precioSinIva"]);
				$this->smarty->assign('precioTotal', $post ["precioTotal"]);
				$this->smarty->assign('opc_formasPago',$formasPago);
				$this->smarty->assign('msgMinimo', $post ["msgMinimo"]);
				
				$this->smarty->assign('baseImpuestos',$post ["baseImpuestos"]); 
				$this->smarty->assign('precioSinIva',$post ["precioSinIva"]);
				$this->smarty->assign('precioTotal',$post ["precioTotal"]);
				
				$this->obtenerDatosCliente($codcliente);
				$this->productosFactura  = $this->mdlFacturacion->seleccionarProductosFactura($codfactura);
				$this->smarty->assign('lineas',$this->productosFactura);
				$this->smarty->display(CtrlAdminVentas::VISTA_PAGAR);
			// Fin Recargar pagina 
		}
		
		private function imprimirFactura(){
			
			$codfactura	= $_GET["codfactura"];
			$pagado		= $_GET["pagado"];
			$adevolver	= $_GET["adevolver"];
			$formapago  = $_GET["formapago"];
			
			$this->voFabrica = VOFabrica::crear(VOFabrica::FACTURA);
			$this->voFabrica->codfactura = $codfactura;
			
			$this->smarty->assign('formapago',$this->mdlFacturacion->seleccionarFormaPago($formapago));
			
			$fechacobro = $this->mdlFacturacion->selecionarFechaCobroFactura($this->voFabrica);
			
			$this->productosFactura  = $this->mdlFacturacion->seleccionarProductosFactura($codfactura);
			$this->smarty->assign('lineas',$this->productosFactura);
			$this->smarty->assign('baseImpuestos',$this->mdlFacturacion->baseTotalImpuestosFact); 
			$this->smarty->assign('precioSinIva',$this->mdlFacturacion->precioTotalFactSinIva);
			$this->smarty->assign('precioTotal',$this->mdlFacturacion->precioTotalFact);
			
			
			$impuestos = $this->mdlFacturacion->seleccionarIvasProductosFactura($codfactura);
			$this->smarty->assign('impuestos',$impuestos);
				
			$this->smarty->assign('nomEmpresa',$this->mdlParametrizacion->nomEmpresa);
			$this->smarty->assign('descripcion',$this->mdlParametrizacion->descripcion);//se llamaba giro
			$this->smarty->assign('rutEmpresa',$this->mdlParametrizacion->rutEmpresa);
			$this->smarty->assign('telefono',$this->mdlParametrizacion->telefono);
			
			$this->smarty->assign('resolucionsii',$this->mdlParametrizacion->resolucionsii);
			$this->smarty->assign('giro2',$this->mdlParametrizacion->giro2);
			
			$this->smarty->assign('direccion',$this->mdlParametrizacion->direccion);
			$this->smarty->assign('comuna',$this->mdlParametrizacion->comuna);
			$this->smarty->assign('ciudadActual',$this->mdlParametrizacion->CiudadActual);
			$this->smarty->assign('fechaCobro',$fechacobro);
			$this->smarty->assign('codfactura',$codfactura);
			$this->smarty->assign('pagado',$pagado); 
			$this->smarty->assign('adevolver',$adevolver);
			
			
			$this->smarty->assign('lineas',$this->productosFactura);
			$this->smarty->display(CtrlAdminVentas::VISTA_IMPRESION);
			
		}
		
	}//end class
?>