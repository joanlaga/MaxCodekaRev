<?
	require_once("CtrlAutoLoad.php");
	
	$ctrlAdminVentas = new CtrlAdminCaja();
	
	if(isset($_POST) && sizeof($_POST) != 0){
		$ctrlAdminVentas->initPost($_POST);
	}
	else if(isset($_GET) && sizeof($_GET) != 0){
		$ctrlAdminVentas->iniGet($_GET);
	}
	else{
		$ctrlAdminVentas->paginaApertura();
	}
	
	class CtrlAdminCaja{
		
		const VISTA_APERTURA = 'VstCajaAbrir.tpl';
		const VISTA_CIERRE   = 'VstCajaCerrar.tpl';
		
		public  $smarty;
		private $mdlCaja;
		private $mdlFacturacion;
		
		private $voFabrica;
		
		public function __construct(){
			$this->smarty 		  = new CustomSmarty();	
			$this->mdlCaja  	  = new MdlCaja();
			$this->mdlFacturacion = new MdlFacturacion();
		}
		
		public function paginaApertura(){
			$this->smarty->display(CtrlAdminCaja::VISTA_APERTURA);
		}
		public function iniGet($get){
			if($get["accion"] == 'abrir'){
				$this->paginaApertura();
			}
			else if($get["accion"] == 'cerrar'){
				$this->realizarArqueo();
			}
		}
		
		public function initPost($post){
			echo "post";
		}
		
		private function realizarArqueo(){
			session_start(); 
			$this->voFabrica = VOFabrica::crear(VOFabrica::CAJA);
			$this->voFabrica->idUser = $_SESSION['usuario_id'];
			
			if($this->mdlCaja->estaAbierta($this->voFabrica)){
			
				/* todo sale con el vo caja
				$fechaApertura = $this->mdlCaja->datos["fechaApertura"];
				$idCaja        = $this->mdlCaja->datos["idCaja"];
				$vlrApertura   = $this->mdlCaja->datos["valorApertura"];*/
				
				$this->voFabrica->fechaApertura = $this->mdlCaja->voFabrica->fechaApertura; //SEOD ESTORA
				$this->voFabrica->idCaja 		= $this->mdlCaja->voFabrica->idCaja; 
				
				$voAux = VOFabrica::crear(VOFabrica::FACTURA);
				$voAux->fecha = $this->voFabrica->fechaApertura;
				
				/*
				
				echo "<pre>";
					print_r($voAux);
				echo "</pre>";*/
				
				$this->mdlFacturacion->totalFacturasDesdeAperturaCaja($voAux);
				$totalVentas = $this->mdlFacturacion->voFabrica->totalfactura;
				$this->voFabrica->valorCierre = $totalVentas; //el valor real del cierre se hace desde el modelo de caja
				$this->mdlCaja->cerrar($this->voFabrica);
				$this->voFabrica = $this->mdlCaja->voFabrica;
				
				/*$totalVentas = $this->mdlFacturacion->voFabrica->totalfactura;
				
				echo "<br> total ventas ".$totalVentas;
				echo "<br> valor apertura ".$this->voFabrica->valorApertura;
				
				//$this->voFabrica->valorCierre  = $totalVentas + $this->voFabrica->valorApertura;
				
				echo "<pre>";
					print_r($this->voFabrica);
				echo "</pre>";
				
				
				$this->voFabrica->valorCierre = $this->mdlCaja->voFabrica->valorCierre;
				echo "<br> valor cerrrar ".$this->voFabrica->valorCierre;*/
				
				$this->smarty->assign("vlrApertura",$this->voFabrica->valorApertura);
				$this->smarty->assign("vlrCierre",$this->voFabrica->valorCierre );
				$this->smarty->assign("totalVentas",$totalVentas);
				$this->smarty->display(CtrlAdminCaja::VISTA_CIERRE);
			}
			else {
				?>
					<script>
                        alert("La Caja ya esta CERRADA");
                    </script>
                
                <? 
			}
			
		}
		
	}//end class
?>