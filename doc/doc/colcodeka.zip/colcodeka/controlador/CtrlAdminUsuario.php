<?
	require_once("CtrlAutoLoad.php");
	
	$ctrlAdminUsuarios = new CtrlAdminUsuario();
	
	if(isset($_POST) && sizeof($_POST) != 0){
		$ctrlAdminUsuarios->initPost($_POST);
	}
	else if(isset($_GET) && sizeof($_GET) != 0){
		$ctrlAdminUsuarios->iniGet($_GET);
	}
	else{
		$ctrlAdminUsuarios->smarty->display(CtrlAdminUsuario::VISTA_ADMINISTRAR);
	}
	
	class CtrlAdminUsuario{
		
		const VISTA_ADICIONAR   = 'VstAddUsuario.tpl';
		const VISTA_ACTUALIZAR  = 'VstActualizarUsuario.tpl';
		const VISTA_DETALLE     = 'VstDetalleUsuarios.tpl';
		const VISTA_ADMINISTRAR = 'VstAdminUsuario.tpl';
		const VISTA_ERROR       = 'VstDefault.tpl';
		
		public  $smarty;
		private $usuariosDao;
		
		private $primerNombre;
		private $segundoNombre;
		private $primerApellido;
		private $segundoApellido;
		private $idUserRol;
		private $usuario;
		private $clave;
		private $idUser;
		
		
		public function __construct(){
			$this->smarty   = new CustomSmarty();	
			$this->usuariosDao = new DaoUsuario();
		}
		
		public function initPost($post){
			
			if($post["nuevoUsuario"]){
				$this->smarty->display(CtrlAdminUsuario::VISTA_ADICIONAR);
			}
			else if($post["consultarUsuarios"])
			{
				$this->consultarUsuarios();
			}
			else if($post["agregarUsuario"])
			{
				$this->configurarUsuario($post,'agregar');
			}
			else if($post["actualizarUsuario"])
			{
				$this->idUser = $post['idUser'];
				$this->configurarUsuario($post,'actualizar');
			}
		}
		
		public function iniGet($get){
			if ($get["accion"] == "eliminarUsuario") 
			{ 
				$result   = $this->usuariosDao->eliminar($get["codUsuario"]);
				//echo "llego para eliminar el usuario";
				//$smarty->display('VstDefault.tpl');
				$this->consultarUsuarios();
			}
			else if ($get["accion"] == "modificarUsuario")
			{
				$result   = $this->usuariosDao->seleccionarTodo($get["codUsuario"]);
				$num      = mysql_num_rows($result);
				
				if ( $num == 1 ) {
					
					while ($row = mysql_fetch_assoc($result)) {
						$this->smarty->assign("primerNombre",$row["primerNombre"]);
						$this->smarty->assign("segundoNombre",$row["segundoNombre"]);
						$this->smarty->assign("primerApellido",$row["primerApellido"]);
						$this->smarty->assign("segundoApellido",$row["segundoApellido"]);
						$this->smarty->assign("nombreRol",$row["nombreRol"]);
						$this->smarty->assign("idUser",$row["idUser"]);
						$this->smarty->assign("usuario",$row["usuario"]);
						$this->smarty->assign("clave",$row["clave"]);
					}
					$this->smarty->display(CtrlAdminUsuario::VISTA_ACTUALIZAR);
				}
				else {
					$this->smarty->display(CtrlAdminUsuario::VISTA_ERROR);
				}
			}
		}
		
		private function configurarUsuario($post, $opt){
		
			$keys_post = array_keys($post);
			
			foreach ($keys_post as $key_post)
			{	
			
				switch ($key_post) {
					case 'primerNombre':
						$this->primerNombre = $post[$key_post];
						break;
					case 'segundoNombre':
						$this->segundoNombre = $post[$key_post];
						break;
					case 'primerApellido':
						$this->primerApellido = $post[$key_post];
						break;
					case 'segundoApellido':
						$this->segundoApellido = $post[$key_post];
						break;
					case 'rol':
						$this->idUserRol = $post[$key_post];
						break;
					case 'usuario':
						$this->usuario = $post[$key_post];
						break;	
					case 'clave':
						$this->clave = $post[$key_post];
						break;				
				}
			 } 
			 $this->opcionesDaoUsuario($opt);
		}
		
		private function opcionesDaoUsuario($opt){
			switch($opt){
				case 'agregar':
					$this->usuariosDao->insertar($this->primerNombre,$this->segundoNombre,$this->primerApellido,$this->segundoApellido,$this->idUserRol,$this->usuario,$this->clave);
					break;
				case 'actualizar':
					$this->usuariosDao->actualizar($this->primerNombre,$this->segundoNombre,$this->primerApellido,$this->segundoApellido,$this->idUserRol,$this->usuario,$this->clave,$this->idUser);
					break;	
		 	}
			$this->consultarUsuarios();
		}
		
		private function consultarUsuarios(){
			$result   = $this->usuariosDao->consultaUsuarios();
			$num      = mysql_num_rows($result);
			
			if ( $num != 0 ) {
				
				$usuarios = array();
				$i = 0;
				
				while ($row = mysql_fetch_assoc($result)) {
					$usuarios[$i] = array("primerNombre" => $row["primerNombre"], "segundoNombre" => $row["segundoNombre"], "primerApellido" =>$row["primerApellido"],
										  "segundoApellido" => $row["segundoApellido"],	"nombreRol" =>$row["nombreRol"], "idUser"=>$row["idUser"]);
					$i = $i+1;								 
				}
				
				$this->smarty->assign('numeFilas',$num);
				$this->smarty->assign('usuarios',$usuarios);
				$this->smarty->display(CtrlAdminUsuario::VISTA_DETALLE);
			}
			else {
				$smarty->display(CtrlAdminUsuario::VISTA_ERROR);
			}
		}
	}//end class
?>