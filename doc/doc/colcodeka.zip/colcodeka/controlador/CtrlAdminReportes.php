<?
	require_once("CtrlAutoLoad.php");
	require_once("../funciones/fechas.php");
	
	$ctrlAdminReportes = new CtrlAdminReportes();
	
	if(isset($_POST) && sizeof($_POST) != 0){
		$ctrlAdminReportes->initPost($_POST);
	}
	else{
		$ctrlAdminReportes->paginaAdminReportes();
	}
	
	class CtrlAdminReportes{
		
		const VISTA_REPORTES 	= 'VstAdminReportes.tpl';
		const VISTA_DETALLE     = 'VstReporteVentasxArticulo.tpl';
		const VISTA_DETALLE2    = 'VstReporteVentasxArticuloDetallado.tpl';
		const VISTA_DETALLE3    = 'VstReporteVentasxCategoria.tpl';
		const VISTA_ERROR       = 'VstDefault.tpl';
		
		public  $smarty;
		private $mdlReportes;
		
		public function __construct(){
			$this->smarty          		  = new CustomSmarty();	
			$this->mdlReportes 	    	  = new MdlReportes();
		}
		
		public function paginaAdminReportes(){
			$this->smarty->display(CtrlAdminReportes::VISTA_REPORTES);
		}
		
		public function fechaGeneracion(){
			$hoy = date("d/m/Y");
			$this->smarty->assign("hoy",$hoy );
			$this->smarty->display(CtrlAdminReportes::VISTA_REPORTES);
		}
		
		
		public function initPost($post){
			if($post["accion"] == "ventasProductos"){
				$this->cargarventasxfecha($post);
			}else if ($post["accion2"] == "ventasProductosDetallado"){
				$this->cargarventasxfecha2($post);
			}else if ($post["accion3"] == "ventasCategoria"){
				$this->cargarventasxfecha3($post);
			}
		}
				
		public function cargarventasxfecha($post){

			$fechaini = explota($post["fechaIni"]);//  ojo aca explote fecha
			$fechafin = explota($post["fechaFin"]);
			
			$this->smarty->assign('lineas',$this->mdlReportes->repVentasxFecha($fechaini,$fechafin));
			$this->smarty->display(CtrlAdminReportes::VISTA_DETALLE);
		}
		public function cargarventasxfecha2($post){

			$fechaini3 = explota($post["fechaIni3"]);//  ojo aca explote fecha
			$fechafin4 = explota($post["fechaFin4"]);
			$idproducto = $post["idproducto"];			
			
			$this->smarty->assign('lineas',$this->mdlReportes->repVentasxArticulo($fechaini3, $fechafin4, $idproducto));
			$this->smarty->display(CtrlAdminReportes::VISTA_DETALLE2);
		}
		public function cargarventasxfecha3($post){

			$fechaini5 = explota($post["fechaIni5"]);//  ojo aca explote fecha
			$fechafin6 = explota($post["fechaFin6"]);
			$idcategoria = $post["idcategoria"];
			
			$this->smarty->assign('lineas',$this->mdlReportes->repVentasxCategoria($fechaini5,$fechafin6,$idcategoria));
			$this->smarty->display(CtrlAdminReportes::VISTA_DETALLE3);
		}

		
	}//end class
?>