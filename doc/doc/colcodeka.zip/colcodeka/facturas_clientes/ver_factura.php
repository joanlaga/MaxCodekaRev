<?
include ("../conectar.php"); 
include ("../funciones/fechas.php"); 

$codfactura=$_GET["codfactura"];
$cadena_busqueda=$_GET["cadena_busqueda"];

$query="SELECT * FROM facturas WHERE codfactura='$codfactura'";
$rs_query=mysql_query($query);
$codcliente=mysql_result($rs_query,0,"codcliente");
$fecha=mysql_result($rs_query,0,"fecha");
$iva=mysql_result($rs_query,0,"iva");

?>

<html>
	<head>
		<title>Principal</title>
		<link href="../estilos/estilos.css" type="text/css" rel="stylesheet">
		<script language="javascript">
		var cursor;
		if (document.all) {
		// Está utilizando EXPLORER
		cursor='hand';
		} else {
		// Está utilizando MOZILLA/NETSCAPE
		cursor='pointer';
		}
		
		function aceptar() {
			location.href="index.php?cadena_busqueda=<? echo $cadena_busqueda?>";
		}
		
		function imprimir(codfactura) {
			window.open("../fpdf/imprimir_factura.php?codfactura="+codfactura);
		}
		
		</script>
	</head>
	<body>
		<div id="pagina">
			<div id="zonaContenido">
				<div align="center">
					<div id="tituloForm" class="headerCol"> VER FACTURA </div>
                    <p>&nbsp;</p>
                    <div id="frmBusqueda">
                    	<table width="50%" class="fuente9" cellspacing=0 cellpadding=3 bgcolor="#FFFFFF">
                          <tr >
                            <td align="center">MercaExito</td>
                          </tr>
                          <tr>
                            <td align="center">Nit: 8605846-1</td>
                          </tr>
                          <tr>
                            <td align="center">La Calera - Punto 1</td>
                          </tr>
                          <tr>
                            <td align="center">Cra 68 # 10 -96</td>
                          </tr>
                          <tr>
                            <td>
                                <table width="100%">
                                    <tr>
                                        <td>Ciudad: Bogota</td>
                                        <td>Telefono: 3210903412</td>
                                    </tr>
                                    <tr>
                                        <td>Caja: 1</td>
                                        <td>Tiquete: 3210903412</td>
                                    </tr>
                                     <tr>
                                        <td>Consecutivo</td>
                                        <td>120903412</td>
                                    </tr>
                                    <tr>
                                        <td>Vendedor</td>
                                        <td>Vicky Davila</td>
                                    </tr>
                                    <tr>
                                        <td>Fecha 12/12/2012</td>
                                        <td>Hora 12:12:12</td>
                                    </tr>
                                    <tr>
                                        <td>Cliente</td>
                                        <td>Daniel</td>
                                    </tr>
                                    <tr>
                                        <td>Nit o Cedula</td>
                                        <td>10000543</td>
                                    </tr>
                                </table>
                            </td>
                          </tr>
                          
                          <tr>
                            <td>
                                <table width="100%">
                                    <tr>
                                      <td>=============================================================</td>
                                    </tr>
                                </table>
                            </td>
                          </tr>
                          
                          <tr>
                            <td>
                                <table width="100%">
                                    <tr>
                                        <td>Codigo</td>
                                        <td>Descripcion</td>
                                    </tr>
                                    <tr>
                                        <td>Caja: 1</td>
                                        <td>Tiquete: 3210903412</td>
                                    </tr>
                                </table>
                            </td>
                          </tr>
                          <tr>
                            <td>
                                <table width="100%">
                                    <tr>
                                      <td>=============================================================</td>
                                    </tr>
                                </table>
                            </td>
                          </tr>
                          
                          <tr><!--ACA ES DONDE VA EL DETALLE DE LOS PRODUCTOS COMPRADOS--->
                            <td>
                                <table width="100%">
                                    <tr>
                                      <td>1112222</td>
                                      <td>LECHE</td>
                                      <td>2221 SIN IVA</td>
                                      <td>9990 PRECIO</td>
                                    </tr>
                                    <tr>
                                      <td>1112222</td>
                                      <td>LECHE</td>
                                      <td>2221 SIN IVA</td>
                                      <td>9990 PRECIO</td>
                                    </tr>
                                    <tr>
                                      <td>1112222</td>
                                      <td>LECHE</td>
                                      <td>2221 SIN IVA</td>
                                      <td>9990 PRECIO</td>
                                    </tr>
                                </table>
                            </td>
                          </tr>
                          
                         <tr>
                            <td>
                                <table width="100%">
                                    <tr>
                                      <td>---------------------INFORMACION IVA ------------------------</td>
                                    </tr>
                                </table>
                            </td>
                          </tr>
                           <tr>
                            <td><!--ACA ES DONDE INFORMACION ADICIONAL--->
                                <table width="100%">
                                    <tr>
                                      <td>VENTA A GRAVAMEN</td>
                                      <td>2111</td>
                                    </tr>
                                    <tr>
                                      <td>DESCUENTO TOTAL</td>
                                      <td>1111</td>
                                    </tr>
                                    <tr>
                                      <td>TOTAL IVA </td>
                                      <td>1231</td>
                                    </tr>
                                </table>
                            </td>
                          </tr>
                          <tr>
                            <td>
                                <table width="100%">
                                    <tr>	
                                      <td>----------------------- PAGO CLIENTE ------------------------</td>
                                    </tr>
                                </table>
                            </td>
                          </tr>
                          <tr>
                            <td><!--ACA ES DONDE INFORMACION ADICIONAL--->
                                <table width="100%">
                                    <tr>
                                      <td>TOTAL</td>
                                      <td>2111</td>
                                    </tr>
                                    <tr>
                                      <td>EFECTIVO</td>
                                      <td>1111</td>
                                    </tr>
                                    <tr>
                                      <td>CAMBIO</td>
                                      <td>1231</td>
                                    </tr>
                                </table>
                            </td>
                          </tr>
                          
                          <tr><!--Aspecto legal--->
                            <td>
                                <table width="100%">
                                    <tr align="center" >
                                      <td width="1197" ><p>RESOLUCION DIAN NO 32424 DESDE 0000001 HASTA 00003 IVA RESIDE EN COLCODEKABLA BLA BLA AADGADSGASDGADSGASDGASGASD</p>
                                      <p>ASGASDGASDGASDGASDGASDGASDGASDGAS</p>
                                      <p>GADSGASDGASDGASDGASDGASDGASDGADSGASD</p></td>
                                    </tr>
                                </table>
                            </td>
                          </tr>
                        </table>
                    </div>    
                    
                    <div id="frmBusqueda">
                        <table class="fuente8" width="98%" cellspacing=0 cellpadding=3 border=0>
                            <? 
                             	$sel_cliente = "SELECT * FROM clientes WHERE codcliente='$codcliente'"; 
                              	$rs_cliente  = mysql_query($sel_cliente); 
							 ?>
                            <tr align="center"><h1>MercaExito</h1></tr>
                            <tr>
                                <td width="15%">Cliente</td>
                                <td width="85%" colspan="2"><?php echo mysql_result($rs_cliente,0,"nombre");?></td>
                            </tr>
                            <tr>
                                <td width="15%">RUT</td>
                                <td width="85%" colspan="2"><?php echo mysql_result($rs_cliente,0,"nif");?></td>
                            </tr>
                            <tr>
                              <td>Direcci&oacute;n</td>
                              <td colspan="2"><?php echo mysql_result($rs_cliente,0,"direccion"); ?></td>
                          </tr>
                            <tr>
                              <td>C&oacute;digo de factura</td>
                              <td colspan="2"><?php echo $codfactura?></td>
                          </tr>
                          <tr>
                              <td>Fecha</td>
                            <td colspan="2">&nbsp;</td>
                          </tr>
                          <tr>
                              <td>IVA</td>
                              <td colspan="2"><?php echo $iva?> %</td>
                          </tr>
                          <tr>
                              <td></td>
                              <td colspan="2"></td>
                          </tr>
                      </table>
                      
                      <table class="fuente8" width="98%" cellspacing=0 cellpadding=3 border=0 ID="Table1">
                            <tr class="cabeceraTabla">
                                <td width="5%">ITEM</td>
                                <td width="25%">REFERENCIA</td>
                                <td width="30%">DESCRIPCION</td>
                                <td width="10%">CANTIDAD</td>
                                <td width="10%">PRECIO</td>
                                <td width="10%">DCTO %</td>
                                <td width="10%">IMPORTE</td>
                            </tr>
                      </table>
                      <table class="fuente8" width="98%" cellspacing=0 cellpadding=3 border=0 ID="Table1">
                          <? $sel_lineas="SELECT factulinea.*,articulos.*,familias.nombre as nombrefamilia FROM factulinea,articulos,familias WHERE factulinea.codfactura='$codfactura' AND factulinea.codigo=articulos.codarticulo AND factulinea.codfamilia=articulos.codfamilia AND articulos.codfamilia=familias.codfamilia ORDER BY factulinea.numlinea ASC";
    $rs_lineas=mysql_query($sel_lineas);
                            for ($i = 0; $i < mysql_num_rows($rs_lineas); $i++) {
                                $numlinea=mysql_result($rs_lineas,$i,"numlinea");
                                $codfamilia=mysql_result($rs_lineas,$i,"codfamilia");
                                $nombrefamilia=mysql_result($rs_lineas,$i,"nombrefamilia");
                                $codarticulo=mysql_result($rs_lineas,$i,"codarticulo");
                                $referencia=mysql_result($rs_lineas,$i,"referencia");
                                $descripcion=mysql_result($rs_lineas,$i,"descripcion");
                                $cantidad=mysql_result($rs_lineas,$i,"cantidad");
                                $precio=mysql_result($rs_lineas,$i,"precio");
                                $importe=mysql_result($rs_lineas,$i,"importe");
                                $descuento=mysql_result($rs_lineas,$i,"dcto");
                                if ($i % 2) { $fondolinea="itemParTabla"; } else { $fondolinea="itemImparTabla"; } ?>
                                        <tr class="<? echo $fondolinea?>">
                                            <td width="5%" class="aCentro"><? echo $i+1?></td>
                                            <td width="25%"><? echo $referencia?></td>
                                            <td width="30%"><? echo $descripcion?></td>
                                            <td width="10%" class="aCentro"><? echo $cantidad?></td>
                                            <td width="10%" class="aCentro"><? echo $precio?></td>
                                            <td width="10%" class="aCentro"><? echo $descuento?></td>
                                            <td width="10%" class="aCentro"><? echo $importe?></td>
                                        </tr>
                                        <? $baseimponible=$baseimponible+$importe; ?>
                        <? } ?>
                      </table>
                  </div>
			  <? $baseimpuestos=$baseimponible*($iva/100);
				$preciototal=$baseimponible+$baseimpuestos;
				$preciototal=number_format($preciototal,2); ?>
					<div id="frmBusqueda">
					<table width="25%" border=0 align="right" cellpadding=3 cellspacing=0 class="fuente8">
						<tr>
							<td width="15%">Base imponible</td>
							<td width="15%"><?php echo number_format($baseimponible,2);?> <? echo $simbolomoneda ?></td>
						</tr>
						<tr>
							<td width="15%">IVA</td>
							<td width="15%"><?php echo number_format($baseimpuestos,2);?> <? echo $simbolomoneda ?></td>
						</tr>
						<tr>
							<td width="15%">Total</td>
							<td width="15%"><?php echo $preciototal?> <? echo $simbolomoneda ?></td>
						</tr>
					</table>
			  </div>
				<div id="botonBusqueda">
					<div align="center">
					  <img src="../img/botonaceptar.jpg" width="85" height="22" onClick="aceptar()" border="1" onMouseOver="style.cursor=cursor">
					 <img src="../img/botonimprimir.jpg" width="79" height="22" border="1" onClick="imprimir(<? echo $codfactura?>)" onMouseOver="style.cursor=cursor">
				        </div>
					</div>
			  </div>
		  </div>
		</div>
	</body>
</html>
